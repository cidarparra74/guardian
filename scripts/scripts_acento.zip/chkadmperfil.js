
function validar(form) {

	// campos requeridos que no esten vacios
	if (!novacio(form.nombre,form.nombre.value.length,1,"el nombre del perfil, ")){return false;}
	
	
}
