
function verificar_pss(){

	var txt= document.getElementById("password0").value
	txt = txt.replace(/ /g, "");
	if(txt==''){
		alert("Ingrese su contrase�a actual.");
		document.getElementById("password0").focus();
		return false;
	}
	var txt= document.getElementById("password1").value
	txt = txt.replace(/ /g, "");
	if(txt==''){
		alert("Ingrese la contrase�a nueva por favor.");
		document.getElementById("password1").focus();
		return false;
	}
	if(txt.length < 6){
		alert("Ingrese la contrase�a nueva con 6 o m�s caracteres.");
		document.getElementById("password1").focus();
		return false;
	}

		var txt2= document.getElementById("password2").value
		txt2 = txt2.replace(/ /g, "");
		if(txt2==''){
			alert("Repita la contrase�a nueva por favor.");
			document.getElementById("password2").focus();
			return false;
		}

		if(txt!=txt2){
			alert("Las contrase�as no coinciden!");
			document.getElementById("password1").focus();
			return false;
		}
	

	return true;
}
