// ***** 
function validar(form) {

	// campos requeridos que no esten vacios
	
	if (!novacio(form.idtipo,form.idtipo.value.length,0,"Id. de tipo de documento, ")){return false;}
	
	//  que no contengan valores invalidos
	//
}
